class Kiwoom():
    def __init__(self):
        print("Kiwoom() class start.")
