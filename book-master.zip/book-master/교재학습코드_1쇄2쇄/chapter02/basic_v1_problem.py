print("========== 문제 1 ==========")
stock_name = "키움증권"
stock_price = 3900
stock_percent = 3.8
print("주식이름 : %s, 가격 : %s원, 등락율 : %s" % (stock_name, stock_price, stock_percent))


print("\n\n========== 문제 2 ==========")
print("등락율 : %s %%" % stock_percent)
print("등락율 : %s %s" % (stock_percent, "%"))